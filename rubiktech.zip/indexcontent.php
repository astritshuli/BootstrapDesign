



<div class="new">
<div class="container">
    <div class="col-sm-12" style="margin-top: 30px;" >
        <h2>Focus su piccole e medie imprese con<br>
forti potenzialità di crescita</h2>
<br>
<l> Lorem ipsum .Lorem ipsum .Lorem ipsum .Lorem ipsum .Lorem ipsum .Lorem ipsum .<br>
Lorem ipsum .Lorem ipsum .Lorem ipsum .</l>
<br>
<h6><a style="color:orange; " href="#">Leggi di piu</a></h6>
</div>
<div class="col-sm-3"> 
<i class="newfont fa fa-globe" style="    font-size: 30px;"></i>   
<p class="box">
<b>Approccio unico al</b><br>
<b>Capitale per la Crescita</b>
<br>
    ____
<br>
<br>
Operiamo per far crescere le
aziende in cui investiamo usando
un approccio essibile e proattivo,
acquisendo le giuste leve di
controllo strategico.
</p>
</div>
<div class="col-sm-3">   
<i class="newfont fa fa-umbrella" style="    font-size: 30px;"></i> 
<p class="box">
<b>Approccio unico al</b><br>
<b>Capitale per la Crescita</b><br>
    ____
<br>
<br>
Operiamo per far crescere le
aziende in cui investiamo usando
un approccio essibile e proattivo,
acquisendo le giuste leve di
controllo strategico.
</p>
</div>

<div class="col-sm-3">   
<i class="newfont fa fa-user-o" style="    font-size: 30px;"></i> 
<p class="box">
<b>Approccio unico al</b><br>
<b>Capitale per la Crescita</b><br>
    ____
<br>
<br>
Operiamo per far crescere le
aziende in cui investiamo usando
un approccio essibile e proattivo,
acquisendo le giuste leve di
controllo strategico.
</p>
</div>

<div class="col-sm-3">  
<i class="newfont fa fa-star-o" style="    font-size: 30px;"></i>  
<p class="box">
<b>Approccio unico al</b><br>
<b>Capitale per la Crescita</b><br>
    ____
<br>
<br>
Operiamo per far crescere le
aziende in cui investiamo usando
un approccio essibile e proattivo,
acquisendo le giuste leve di
controllo strategico.
</p>
</div>
</div>
</div>


