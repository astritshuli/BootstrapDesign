
   
    <div class="row carouselslider">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="uploads/images/asset.jpg" alt="Los Angeles" style="width:100%;">
        <div class="carousel-caption">
        
        </div>
        <div style="   padding-bottom: 40px;
    text-align: left;
    font-size: 10px;
    margin-left: -23px;" class="carousel-caption mobile-only">
          <h3  style="color:#00273F;">Leader test Capitale<br>
              per la ipsum</h3>
              <g style="color:#00273F;">Lorem ipsum dolor sit amet, consectetuer adipiscing elit,<br>
sed diam nonummy nibh euismod tincidunt</g>
        </div>
        <div style="    top: 24%;
    padding-bottom: 30px;
    text-align: left;
    margin-left: -70px;" class="desktop-only carousel-caption">
    
          <h1  style="color:#00273F;">Leader test Capitale<br>
              per la ipsum</h1>
          <g style="color:#00273F;">Lorem ipsum dolor sit amet, consectetuer adipiscing elit,<br>
sed diam nonummy nibh euismod tincidunt</g>
          <br><br>
          <button class="buttonslider">Ricevi appuntamenti</button>
        </div>
      </div>

    
  
    </div>

   
  </div>
</div>
