<div class="row soluzionirow">
<div class="container carousel">
  <div class="col-sm-12">
  <h2 style="text-align:left;">Le Nostre Soluzioni <hr class="devider1" style="width: 50px;
    border-top: 2px solid #ffa500;"></h2>
    <h5>“Il nostro apporto principale è il SUPPORTO STRATEGICO, perché prima del capitale<br>
c’è la FIDUCIA e la CONDIVISIONE di obiettivi strategici.”
</h5>

  
</div>
	
		<div class="MultiCarousel" data-items="1,2,3,4" data-slide="1" id="MultiCarousel"  data-interval="1000">
            <div class="MultiCarousel-inner">
                <div class="item">
                
                    <div class="pad15">
                        <div class="contentbox">
                    <p  class="lead overlay">Multi Item Carousel</p>
                    </div>
                    <br>
                    <g class="titles">Strategia </g>
                    </div>

                    </div>
                <div class="item">
                     <div class="pad15">
                        <div class="contentbox">
                    <p  class="lead overlay">Multi Item Carousel</p>
                    </div>
                    <br>
                    <g class="titles">Strategia </g>
                    </div>
                </div>
                <div class="item">
                <div class="pad15">
                        <div class="contentbox">
                    <p  class="lead overlay">Multi Item Carousel</p>
                    </div>
                    <br>
                    <g class="titles">Strategia </g>
                    </div>
                </div>
                <div class="item">
                <div class="pad15">
                        <div class="contentbox">
                    <p  class="lead overlay">Multi Item Carousel</p>
                    </div>
                    <br>
                    <g class="titles">Strategia </g>
                    </div>
                </div>
                <div class="item">
                <div class="pad15">
                        <div class="contentbox">
                    <p  class="lead overlay">Multi Item Carousel</p>
                    </div>
                    <br>
                    <g class="titles">Strategia </g>
                    </div>
                </div>
                <div class="item">
                <div class="pad15">
                        <div class="contentbox">
                    <p  class="lead overlay">Multi Item Carousel</p>
                    </div>
                    <br>
                    <g class="titles">Strategia </g>
                    </div>
                </div>
                <div class="item">
                <div class="pad15">
                        <div class="contentbox">
                    <p  class="lead overlay">Multi Item Carousel</p>
                    </div>
                    <br>
                    <g class="titles">Strategia </g>
                    </div>
                </div>
                
            </div>
            <button class="btn btn-primary leftLst" style="color: #fff;
                background-color: #F68F2F;
                border-color: #F68F2F;"><</button>
            <button class="btn btn-primary rightLst"style="color: #fff;
                background-color: #F68F2F;
                border-color: #F68F2F;">></button>
        </div>
	</div>