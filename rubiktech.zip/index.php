<?php 
include_once "actionheader.php";
include_once "layout_header.php";
include_once "slider.php";
include_once "indexcontent.php"; 
include_once "carousel.php";
include_once "indexcontentback.php";
include_once "clients.php";
include_once "layout_footer.php";










?>