<div  class="navbar navbar-default navigation  " style=" background-color: #F68F2F;
        border-color: #F68F2F;">
        <div class="container">
          <div class="navbar-header">
          <a style="color:black;" class="navbar-brand" href="#">LOGO</a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            
          </div>
          
          <?php  
        echo "<div class='collapse navbar-collapse'>";
        echo "<ul class='nav navbar-nav'>";
        echo "<li class='halfborder'><a href='#'>HOME</a></li>";
        echo "<li class='halfborder' ><a href='#'>CHISIAMO </a></li>";
        echo "<li class='halfborder' ><a href='#'>INVESTIMENTI </a></li>";
        echo "<li class='halfborder' ><a href='#'>STAMPA E NEWS </a></li>";
        echo "<li class='halfborder' ><a href='#'>CONTATTI</a></li>";
        echo "<li class='halfborder' ><a href='#'>ACCESSO SOTTOSCRITTORI</a></li>";
      
              
                    
                
              
        echo "</ul>";
            
          echo "</div>";
          ?>
        </div>
      </div>
