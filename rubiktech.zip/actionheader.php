<div class="row actionheader">
    <div class="container">
          <div class="col-sm-6" >
                 <div style="float:left;"> <i class="fa fa-phone"></i> +39 0425555555.111 </div>
          </div>
                 <div class="col-sm-6" >
                 <div style="float:right;"> <i class="fa fa-facebook-square"></i> 
                 <i class="fa fa-twitter-square"></i> <i class="fa fa-linkedin-square"></i> 
                 <i class="fa fa-instagram"></i>&nbsp;&nbsp; |&nbsp;&nbsp; IT&nbsp;&nbsp; 
                 <i class="fa fa-angle-down"></i></div>
          </div>

     </div>
</div>