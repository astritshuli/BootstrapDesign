<div class="row clientsrow">
   <div class="container clients">
 
 <div class="col-sm-3 paddingmobile">
     <img src="http://mediapro.al/blogdemo/wp-content/uploads/2018/11/Asset-10-2-150x31.png">
</div>

 <div class="col-sm-3 paddingmobile">
 <img src="http://mediapro.al/blogdemo/wp-content/uploads/2018/11/Asset-10-2-150x31.png">
</div>


 <div class="col-sm-3 paddingmobile">
 <img src="http://mediapro.al/blogdemo/wp-content/uploads/2018/11/Asset-10-2-150x31.png">
</div>


 <div class="col-sm-3 paddingmobile">
 <img src="http://mediapro.al/blogdemo/wp-content/uploads/2018/11/Asset-10-2-150x31.png">
</div>

</div> 
</div>
