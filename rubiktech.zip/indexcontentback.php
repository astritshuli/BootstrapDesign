<div class="row contentback">

<div class="content soluzioni">
<div class="col-sm-12" style="text-align:center;">
<h3>Le Nostre Soluzioni</h3>
<hr style="width: 50px;
    border-top: 2px solid #ffa500;">
<h6>“Siamo vicini a chi sa GUARDARE LONTANO.”</h6>
</div>
<div class="col-sm-3">
<i class="fontsoluzioni fa fa-crosshairs" style="    font-size: 60px;"></i> 
    <h4>Target</h4>
</div>
<div class="col-sm-3">
<i class="fontsoluzioni fa fa-users" style="    font-size: 60px;"></i> 
<h4>Partnership </h4>
</div>
<div class="col-sm-3">
<i class="fontsoluzioni fa fa-star-o" style="    font-size: 60px;"></i> 
<h4>Creazione di valore</h4>
</div>
<div class="col-sm-3">
<i class="fontsoluzioni fa fa-list" style="    font-size: 60px;"></i> 
<h4>Trasparenza </h4>
</div>


</div>
</div>